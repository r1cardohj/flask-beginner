# flask-beginner

a quick project directory maker for flask.

**Quick Start**

``` bash
python -m venv env
env\Scripts\activate 
```

then

``` b
(env):pip install flask-beginner
(env):beginner
```

your project will like this

