"""
    Flask-Beginner
    -----------------
    a quick project directory maker for flask.
    :copyright: (c) 2023 by r1cardohj.
    :license: MIT, see LICENSE for more details.
"""
from setuptools import setup

setup()